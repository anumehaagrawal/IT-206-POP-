#!/bin/bash

echo "I a great"&
jobs -l
echo $!
echo "Killi..."
kill $!