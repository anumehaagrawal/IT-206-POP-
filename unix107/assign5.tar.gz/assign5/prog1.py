#!/bin/bash

ps -u student
echo $$