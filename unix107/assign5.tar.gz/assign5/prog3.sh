#!/bin/bash
sort -n file.txt >> file1.txt &
cat file1.txt &
echo &
jobs